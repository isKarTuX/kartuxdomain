import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowRight } from "lucide-react"

interface ContentCardProps {
  title: string
  description: string
  href: string
  delay?: string
}

export function ContentCard({ title, description, href, delay = "0s" }: ContentCardProps) {
  return (
    <Link href={href} className="group">
      <Card
        className="h-full transition-all duration-300 hover:shadow-lg hover:scale-105 hover:border-primary/50 slide-up"
        style={{ animationDelay: delay }}
      >
        <CardHeader>
          <CardTitle className="flex items-center justify-between text-lg group-hover:text-primary transition-colors">
            {title}
            <ArrowRight className="h-5 w-5 opacity-0 group-hover:opacity-100 transform translate-x-0 group-hover:translate-x-1 transition-all duration-200" />
          </CardTitle>
        </CardHeader>
        <CardContent>
          <CardDescription className="text-base leading-relaxed">{description}</CardDescription>
        </CardContent>
      </Card>
    </Link>
  )
}
