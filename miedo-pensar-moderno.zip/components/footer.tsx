import { Brain, Heart } from "lucide-react"

export function Footer() {
  return (
    <footer className="bg-card border-t border-border">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="text-center">
          <div className="flex justify-center items-center mb-4">
            <Brain className="h-8 w-8 text-primary mr-2" />
            <span className="text-xl font-bold text-foreground">Miedo a Pensar</span>
          </div>

          <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
            Un proyecto dedicado a explorar la intersección entre neurociencia, tecnología y bienestar mental en la era
            digital.
          </p>

          <div className="border-t border-border pt-6">
            <p className="text-sm text-muted-foreground flex items-center justify-center">
              Hecho con <Heart className="h-4 w-4 text-red-500 mx-1" /> para fomentar la reflexión crítica
            </p>
            <p className="text-xs text-muted-foreground mt-2">
              &copy; 2025 Pensamientos Críticos en la Era Digital. Todos los derechos reservados.
            </p>
          </div>
        </div>
      </div>
    </footer>
  )
}
