import { Button } from "@/components/ui/button"
import { ArrowDown, Smartphone, Brain } from "lucide-react"
import Link from "next/link"

export function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center bg-gradient-to-br from-background via-card to-background overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 bg-grid-pattern opacity-5"></div>

      <div className="relative z-10 max-w-4xl mx-auto px-4 text-center">
        <div className="fade-in">
          <div className="flex justify-center mb-8">
            <div className="relative">
              <Brain className="h-20 w-20 text-primary animate-pulse" />
              <Smartphone className="h-8 w-8 text-muted-foreground absolute -bottom-2 -right-2 animate-bounce" />
            </div>
          </div>

          <h1 className="text-4xl md:text-6xl font-bold text-foreground mb-6 leading-tight">
            Reflexiones en la <span className="text-primary">Era Digital</span>
          </h1>

          <p className="text-xl md:text-2xl text-muted-foreground mb-8 max-w-3xl mx-auto leading-relaxed">
            Un espacio para desconectar y pensar. Explorando el impacto de la tecnología en nuestra mente y
            redescubriendo el poder del aburrimiento.
          </p>

          <div className="mb-12">
            <blockquote className="text-lg italic text-muted-foreground border-l-4 border-primary pl-6 max-w-2xl mx-auto">
              "¿Cuándo fue la última vez que te permitiste no hacer nada? Absolutamente nada."
            </blockquote>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Link href="/dopamina">
              <Button size="lg" className="text-lg px-8 py-3">
                Comenzar el Viaje
              </Button>
            </Link>
            <Link href="#content">
              <Button variant="outline" size="lg" className="text-lg px-8 py-3 bg-transparent">
                Explorar Contenido
              </Button>
            </Link>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <ArrowDown className="h-6 w-6 text-muted-foreground" />
      </div>
    </section>
  )
}
