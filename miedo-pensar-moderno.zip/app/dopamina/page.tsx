import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowLeft, ArrowRight, Zap } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

export default function DopaminaPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="max-w-4xl mx-auto px-4 py-12">
        <div className="fade-in">
          <div className="text-center mb-12">
            <div className="flex justify-center mb-6">
              <Zap className="h-16 w-16 text-primary" />
            </div>
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
              El Secuestro de los Circuitos Dopaminérgicos
            </h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Descubre cómo las plataformas digitales explotan nuestro sistema de recompensa cerebral
            </p>
          </div>

          <Card className="mb-8">
            <CardContent className="p-8">
              <div className="text-center mb-8">
                <Image
                  src="/placeholder.svg?height=400&width=600"
                  alt="Diagrama del circuito de recompensa cerebral"
                  width={600}
                  height={400}
                  className="rounded-lg mx-auto border border-border"
                />
              </div>

              <div className="prose prose-lg max-w-none">
                <p className="text-lg leading-relaxed mb-6">
                  El principal mecanismo neurobiológico explotado por la tecnología digital es la{" "}
                  <strong className="text-primary">vía mesolímbica de la recompensa</strong>. Este circuito, gobernado
                  por el neurotransmisor dopamina, no regula el placer en sí, sino la motivación y la anticipación de
                  una recompensa.
                </p>

                <p className="text-lg leading-relaxed mb-6">
                  Las plataformas digitales están diseñadas para maximizar la liberación de dopamina a través de{" "}
                  <strong className="text-primary">esquemas de recompensa variable intermitente</strong>, el mismo
                  principio que subyace a la adicción a las máquinas tragamonedas.
                </p>

                <div className="bg-accent/10 border-l-4 border-primary p-6 rounded-r-lg mb-6">
                  <h3 className="text-xl font-semibold text-foreground mb-3">El Bucle de Compulsión</h3>
                  <p className="text-base leading-relaxed">
                    Una notificación, un "me gusta" o el inicio de un video corto representan una recompensa potencial e
                    impredecible. Esta incertidumbre genera picos de dopamina más altos que una recompensa predecible,
                    creando un <em>bucle de compulsión</em>.
                  </p>
                </div>

                <p className="text-lg leading-relaxed">
                  El cerebro aprende a asociar el dispositivo con esta gratificación instantánea, disminuyendo la
                  tolerancia a la gratificación diferida, que es fundamental para tareas complejas como el estudio, la
                  lectura profunda o el desarrollo de habilidades a largo plazo.
                </p>
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-between items-center">
            <Link href="/">
              <Button variant="outline" className="flex items-center gap-2 bg-transparent">
                <ArrowLeft className="h-4 w-4" />
                Inicio
              </Button>
            </Link>
            <Link href="/red-neuronal">
              <Button className="flex items-center gap-2">
                Red Neuronal por Defecto
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
