import { Navigation } from "@/components/navigation"
import { Hero } from "@/components/hero"
import { ContentCard } from "@/components/content-card"
import { Footer } from "@/components/footer"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <main>
        <Hero />
        <section className="py-16 px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12 fade-in">
              <h2 className="text-3xl font-bold text-foreground mb-4">Explorando la Mente Digital</h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Un viaje a través de la neurociencia y la psicología para entender cómo la tecnología está transformando
                nuestra capacidad de pensar.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              <ContentCard
                title="Circuitos Dopaminérgicos"
                description="Descubre cómo las plataformas digitales explotan nuestro sistema de recompensa cerebral."
                href="/dopamina"
                delay="0.1s"
              />
              <ContentCard
                title="Red Neuronal por Defecto"
                description="La importancia del aburrimiento para la creatividad y la introspección."
                href="/red-neuronal"
                delay="0.2s"
              />
              <ContentCard
                title="Carga Cognitiva"
                description="Cómo la sobrecarga de información afecta nuestra capacidad de concentración."
                href="/carga-cognitiva"
                delay="0.3s"
              />
              <ContentCard
                title="Psicología Algorítmica"
                description="La influencia de los algoritmos en nuestros sesgos cognitivos."
                href="/psicologia-algoritmica"
                delay="0.4s"
              />
              <ContentCard
                title="Neuroplasticidad"
                description="Cómo podemos reconfigurar nuestro cerebro a través de la desconexión."
                href="/neuroplasticidad"
                delay="0.5s"
              />
              <ContentCard
                title="Higiene Digital"
                description="Estrategias prácticas para recuperar el control de nuestra atención."
                href="/higiene-digital"
                delay="0.6s"
              />
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}
